<?
include('lib/bitcoin_address.php');
echo "<pre>\n";
print_r(bitcoin_address_pair());